package com.example.idealista.service;

import com.example.idealista.domain.Vivienda;
import com.example.idealista.repository.ViviendaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ViviendaServiceImpl implements ViviendaService{

    @Autowired
    private ViviendaRepository repo;

    @Override
    public List<Vivienda> listAll() {
        return repo.findAll();
    }

    @Override
    public Vivienda findById(Long id) {
        return repo.findById(id).orElse(null);
    }

    @Override
    public Vivienda save(Vivienda vivienda) {
        return repo.save(vivienda);
    }

    @Override
    public void deleteById(Long id) {
        repo.deleteById(id);
    }

    @Override
    public Vivienda update(Vivienda vivienda, Long id) {
        if (repo.existsById(id)){

            vivienda.setId(id);
            return repo.save(vivienda);

        }
        return null; //Excepcion personalizada.
    }
}
