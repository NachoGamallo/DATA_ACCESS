package com.example.idealista.service;

import com.example.idealista.domain.Vivienda;

import java.util.List;

public interface ViviendaService {

    List<Vivienda> listAll();

    Vivienda findById(Long id);

    Vivienda save(Vivienda vivienda);

    void deleteById(Long id);

    Vivienda update(Vivienda vivienda, Long id);

}
