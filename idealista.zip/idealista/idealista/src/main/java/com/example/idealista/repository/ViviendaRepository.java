package com.example.idealista.repository;

import com.example.idealista.domain.Vivienda;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ViviendaRepository extends JpaRepository<Vivienda, Long> { }
