package com.example.idealista.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

@Entity
@Table(name = "vivienda")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Vivienda {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank()
    private String titulo;
    @NotBlank()
    private String ciudad;
    @NonNull
    @Min(0)
    private Integer precio;
    private Integer metros;
    private Integer habitaciones;

}
