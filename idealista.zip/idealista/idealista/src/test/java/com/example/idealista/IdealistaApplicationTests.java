package com.example.idealista;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IdealistaApplicationTests {

	@Test
	void contextLoads() {
	}

}
