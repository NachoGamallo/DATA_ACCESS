package org.example;

import jakarta.persistence.*;

import java.util.Collection;

@Entity
@Table(name = "hotel", schema = "public", catalog = "vacacionesdb")
public class HotelClass {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id", nullable = false)
    private int id;
    @Basic
    @Column(name = "nombre", nullable = false, length = 50)
    private String nombre;
    @Basic
    @Column(name = "ciudad", nullable = false, length = 50)
    private String ciudad;
    @Basic
    @Column(name = "categoria", nullable = true)
    private Integer categoria;
    @OneToMany(mappedBy = "hotelByHotelId")
    private Collection<HabitacionClass> habitacionsById;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public Integer getCategoria() {
        return categoria;
    }

    public void setCategoria(Integer categoria) {
        this.categoria = categoria;
    }

    public Collection<HabitacionClass> getHabitacionsById() {
        return habitacionsById;
    }

    public void setHabitacionsById(Collection<HabitacionClass> habitacionsById) {
        this.habitacionsById = habitacionsById;
    }

    @Override
    public String toString() {
        return "HotelClass{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", ciudad='" + ciudad + '\'' +
                ", categoria=" + categoria +
                '}';
    }
}
