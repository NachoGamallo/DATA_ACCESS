package org.example;

import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.criteria.HibernateCriteriaBuilder;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;
import java.util.Scanner;

public class CRUD {

    static SessionFactory glSessionFactory;
    static Session glSession;
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        try (
                SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
                Session session = sessionFactory.openSession()

                ){

            glSessionFactory = sessionFactory;
            glSession = session;

            //insertions();
            //read();
            update();


        }catch (Exception e){

            e.printStackTrace();

        }

    }

    public static void insertions(){

        Transaction ts = glSession.beginTransaction();
        HotelClass hotel = new HotelClass();
        HabitacionClass h1 = new HabitacionClass();
        HabitacionClass h2 = new HabitacionClass();
        ReservaClass reserva1 = new ReservaClass();

        try {

            //Creación del hotel.
            System.out.println("Creacion del hotel.");

            hotel.setNombre("HotelDelPepino");
            hotel.setCiudad("Lima");
            hotel.setCategoria(1);

            System.out.println("Creación hotel 1");
            glSession.persist(hotel);


            //Creación habitaciones.
            System.out.println("Creacion de las habitaciones.");

            h1.setNumero(12);
            h1.setPrecio(BigDecimal.valueOf(125.12));
            h1.setTipo("Doble cama x2");
            h1.setHotelByHotelId(hotel);

            System.out.println("Creacion de las habitacion 1.");
            glSession.persist(h1);

            h2.setNumero(13);
            h2.setPrecio(BigDecimal.valueOf(150.00));
            h2.setTipo("Suite");
            h2.setHotelByHotelId(hotel);

            System.out.println("Creacion de las habitacion 2.");
            glSession.persist(h2);

            //Creación de las reservas.
            System.out.println("Creación de las reservas.");
            reserva1.setCliente("David");
            reserva1.setFechaEntrada(Date.valueOf("2025-12-8"));
            reserva1.setFechaSalida(Date.valueOf("2025-12-10"));
            reserva1.setHabitacionByHabitacionId(h1);

            System.out.println("Creación reserva 1");
            glSession.persist(reserva1);

            ts.commit();

        }catch (Exception e){
            System.out.println("Error de ejecución");
            e.printStackTrace();
            ts.rollback();
        }

        ts.commit();

    }

    public static void read(){

        System.out.println("----Selecciona todos los hoteles.----");
        List<HotelClass> listHotels = glSession.createQuery("FROM HotelClass",HotelClass.class).list();

        for (HotelClass ht : listHotels){

            System.out.println("Nombre de hotel: " + ht.toString());

        }

        //Seleccionar las habitaciones de un hotel en especifico.
        List<HabitacionClass> listHabitaciones = glSession.createQuery(
                "FROM HabitacionClass WHERE hotelByHotelId.id = :id_hotel",HabitacionClass.class
        ).setParameter("id_hotel",1).list();

        System.out.println("----Listar habitaciones segun un hotel especifico.----");
        for (HabitacionClass hb : listHabitaciones){

            System.out.println("Número de la habitación: " + hb.toString());

        }

        //Listar reservas de una habitación.
        List<ReservaClass> listreservas = glSession.createQuery(
                "FROM ReservaClass WHERE habitacionByHabitacionId.id = :id_habitacion",ReservaClass.class
        ).setParameter("id_habitacion",3).list();

        System.out.println("----Listar las reservas de la habitacion especifica.----");
        for (ReservaClass rs : listreservas){

            System.out.println("Cliente de la reserva: " + rs.toString());

        }

        System.out.println("---Habitaciones segun tipo---");
        System.out.println("Ingresa la categoria por la que filtrar:");
        List<HabitacionClass> listhabitacionesSeguntipo = glSession.createQuery(
                "FROM HabitacionClass WHERE tipo = :categoria",HabitacionClass.class
        ).setParameter("categoria",sc.next()).list();

        for (HabitacionClass hs : listhabitacionesSeguntipo){

            System.out.println(hs.toString());

        }

        System.out.println("---Consulta con CriteriaQuery---");
        HibernateCriteriaBuilder cb = glSession.getCriteriaBuilder();

        CriteriaQuery<HabitacionClass> query = cb.createQuery(HabitacionClass.class);
        Root<HabitacionClass> root = query.from(HabitacionClass.class);
        query.select(root);
        List<HabitacionClass> lista = glSession.createQuery(query).getResultList();
        glSession.close();

        for (HabitacionClass hc : lista){

            System.out.println(hc.toString());

        }
    }

    public static void update(){

        Transaction tx = glSession.beginTransaction();

        //Cambiar categoria del hotel.
        System.out.println("Actualizar categoria del hotel:");
        HotelClass h = glSession.get(HotelClass.class,1);
        h.setCategoria(2);
        glSession.merge(h);


        //cambiar precio de una habitación.
        

        tx.commit();
        
    }

}