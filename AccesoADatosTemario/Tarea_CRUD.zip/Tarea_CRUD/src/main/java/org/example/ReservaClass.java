package org.example;

import jakarta.persistence.*;

import java.sql.Date;

@Entity
@Table(name = "reserva", schema = "public", catalog = "vacacionesdb")
public class ReservaClass {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id", nullable = false)
    private int id;
    @Basic
    @Column(name = "cliente", nullable = false, length = 50)
    private String cliente;
    @Basic
    @Column(name = "fecha_entrada", nullable = false)
    private Date fechaEntrada;
    @Basic
    @Column(name = "fecha_salida", nullable = false)
    private Date fechaSalida;
    @ManyToOne
    @JoinColumn(name = "habitacion_id", referencedColumnName = "id", nullable = false)
    private HabitacionClass habitacionByHabitacionId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public Date getFechaEntrada() {
        return fechaEntrada;
    }

    public void setFechaEntrada(Date fechaEntrada) {
        this.fechaEntrada = fechaEntrada;
    }

    public Date getFechaSalida() {
        return fechaSalida;
    }

    public void setFechaSalida(Date fechaSalida) {
        this.fechaSalida = fechaSalida;
    }

    public HabitacionClass getHabitacionByHabitacionId() {
        return habitacionByHabitacionId;
    }

    public void setHabitacionByHabitacionId(HabitacionClass habitacionByHabitacionId) {
        this.habitacionByHabitacionId = habitacionByHabitacionId;
    }

    @Override
    public String toString() {
        return "ReservaClass{" +
                "id=" + id +
                ", cliente='" + cliente + '\'' +
                ", fechaEntrada=" + fechaEntrada +
                ", fechaSalida=" + fechaSalida +
                '}';
    }
}
