package org.example;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.util.Collection;

@Entity
@Table(name = "habitacion", schema = "public", catalog = "vacacionesdb")
public class HabitacionClass {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id", nullable = false)
    private int id;
    @Basic
    @Column(name = "numero", nullable = false)
    private int numero;
    @Basic
    @Column(name = "tipo", nullable = false, length = 30)
    private String tipo;
    @Basic
    @Column(name = "precio", nullable = false, precision = 2)
    private BigDecimal precio;
    @ManyToOne
    @JoinColumn(name = "hotel_id", referencedColumnName = "id", nullable = false)
    private HotelClass hotelByHotelId;
    @OneToMany(mappedBy = "habitacionByHabitacionId")
    private Collection<ReservaClass> reservasById;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public BigDecimal getPrecio() {
        return precio;
    }

    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }

    public HotelClass getHotelByHotelId() {
        return hotelByHotelId;
    }

    public void setHotelByHotelId(HotelClass hotelByHotelId) {
        this.hotelByHotelId = hotelByHotelId;
    }

    public Collection<ReservaClass> getReservasById() {
        return reservasById;
    }

    public void setReservasById(Collection<ReservaClass> reservasById) {
        this.reservasById = reservasById;
    }

    @Override
    public String toString() {
        return "HabitacionClass{" +
                "id=" + id +
                ", numero=" + numero +
                ", tipo='" + tipo + '\'' +
                ", precio=" + precio +
                ", hotelByHotelId=" + hotelByHotelId +
                '}';
    }
}
